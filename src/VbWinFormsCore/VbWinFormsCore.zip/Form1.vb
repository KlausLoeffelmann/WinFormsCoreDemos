﻿Imports System.Windows.Forms

Public Class Form1

    Private Sub SayHelloButton_Click(sender As Object, e As EventArgs) Handles sayHelloButton.Click
        MessageBox.Show("Hello VB from Windows Forms!")
    End Sub

End Class
